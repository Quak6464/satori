'use client'

import * as React from 'react'
import { Music } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

interface Song {
  title: string
  url: string
}

interface SongDropdownProps {
  songs: Song[]
  currentSongIndex: number
  onSelect: (index: number) => void
  iconSize?: number
}

export function SongDropdown({ songs, currentSongIndex, onSelect, iconSize = 16 }: SongDropdownProps) {
  const [open, setOpen] = React.useState(false)

  const handleSelect = (index: number) => {
    onSelect(index)
    setOpen(false)
  }

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <motion.button
          className="w-6 h-6 flex items-center justify-center"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <Music size={iconSize} />
        </motion.button>
      </DropdownMenuTrigger>
      <AnimatePresence>
        {open && (
          <DropdownMenuContent
            align="start"
            className="w-48 bg-zinc-800/90 backdrop-blur-sm border-zinc-700"
            asChild
          >
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {songs.map((song, index) => (
                <DropdownMenuItem
                  key={index}
                  className={`${
                    currentSongIndex === index ? 'bg-white/10' : ''
                  } hover:bg-white/20 cursor-pointer`}
                  onClick={() => handleSelect(index)}
                >
                  <motion.span
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.2, delay: index * 0.05 }}
                    className="truncate"
                  >
                    {song.title}
                  </motion.span>
                </DropdownMenuItem>
              ))}
            </motion.div>
          </DropdownMenuContent>
        )}
      </AnimatePresence>
    </DropdownMenu>
  )
}

