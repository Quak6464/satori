export const images = {
  background: '/assets/images/background.jpg',
  profile: '/assets/images/profile.jpg',
  avatar: '/assets/images/avatar.jpg'
}

