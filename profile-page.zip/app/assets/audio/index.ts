export const audio = {
  background: '/assets/audio/background.mp3'
}

