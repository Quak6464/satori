import Image from 'next/image'

interface BadgeProps {
  className?: string;
}

const badgeImages = {
  tools: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_20250101_092609_150.jpg-T23ISLq5IicmYIUf36FWhcMyO7R8mF.jpeg",
  wings: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_20250101_092611_670.jpg-TRAhcYh03bLlR6ruj5yvPYzKhLh3yH.jpeg",
  developer: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_20250101_092826_920.jpg-2Ul5zlxHu0IgQjtkYFKoVufdTMOyzH.jpeg",
  bot: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_20250101_092824_244.jpg-4ToC1XACGgGZN1yD8wIiYhxTcAc2K0.jpeg"
}

export const DiscordBadges = {
  ActiveDeveloper: ({ className }: BadgeProps) => (
    <div className={`${className} mix-blend-screen`}>
      <Image 
        src={badgeImages.tools}
        alt="Active Developer Badge"
        width={16}
        height={16}
        className="w-full h-full"
        style={{ mixBlendMode: 'multiply' }}
      />
    </div>
  ),
  VerifiedDeveloper: ({ className }: BadgeProps) => (
    <div className={`${className} mix-blend-screen`}>
      <Image 
        src={badgeImages.developer}
        alt="Verified Developer Badge"
        width={16}
        height={16}
        className="w-full h-full"
        style={{ mixBlendMode: 'multiply' }}
      />
    </div>
  ),
  HypeSquad: ({ className }: BadgeProps) => (
    <div className={`${className} mix-blend-screen`}>
      <Image 
        src={badgeImages.wings}
        alt="HypeSquad Badge"
        width={16}
        height={16}
        className="w-full h-full"
        style={{ mixBlendMode: 'multiply' }}
      />
    </div>
  ),
  Bot: ({ className }: BadgeProps) => (
    <div className={`${className} mix-blend-screen`}>
      <Image 
        src={badgeImages.bot}
        alt="Bot Badge"
        width={16}
        height={16}
        className="w-full h-full"
        style={{ mixBlendMode: 'multiply' }}
      />
    </div>
  )
}

