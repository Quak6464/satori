'use client'

import { useState, useEffect, useRef, useMemo } from 'react'
import { Mail, Volume2, VolumeX, Instagram, MessageSquare, Youtube, Music, Eye } from 'lucide-react'
import Image from 'next/image'
import { TypeAnimation } from 'react-type-animation'
import { motion, AnimatePresence } from 'framer-motion'
import { LandingPage } from '@/components/LandingPage'
import { DiscordBadges } from '@/components/DiscordBadges'
import { SongDropdown } from '@/components/SongDropdown'

const images = {
  background: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_20241219_203349_918-FW23m6TgDvS7OdoOFeMd3d1zySHFA9.webp',
  profile: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG-20241225-WA0004.jpg-Ct7xgNqvpA3qRn7zy1xpxqHndSCknw.jpeg',
  discord: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1ee43888c809854a43074dcd280774b1-2ExEcQUmG9AOA0JK89c4UUrJCmLbK3.png'
}

export const songs = [
  {
    title: "Blue - Yung Kai",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Blue%20-%20Yung%20Kai%20_%20English-G8GPxvGddcRty9CAmB6KnldmorAS8m.mp3"
  },
  {
    title: "Sweater Weather",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/sweater_weather-9aaAIWQu9Er3yxWis3rkCdg1TvVvJ7.mp3"
  },
  {
    title: "One of the Girls",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/one_of_the_girls-m40vvRRBTHwMa8hvyKFacfnWg6Jbyi.mp3"
  },
  {
    title: "Die With A Smile",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Die%20With%20A%20Smile%20Song%20Ringtone%20Download%20-%20MobCup.Com.Co-MrGG82SqKLoiKAiM3rVWWDjohcCHIB.mp3"
  }
]

export default function ProfilePage() {
  const [isMuted, setIsMuted] = useState(false)
  const [volume, setVolume] = useState(0.5)
  const [showVolumeSlider, setShowVolumeSlider] = useState(false)
  const [showLanding, setShowLanding] = useState(true)
  const [showContent, setShowContent] = useState(false)
  const [currentSongIndex, setCurrentSongIndex] = useState(0)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const [isAudioLoaded, setIsAudioLoaded] = useState(false)
  
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const audio = new Audio(songs[currentSongIndex].url);
      audio.loop = true;
      audio.volume = volume;
      audioRef.current = audio;

      const playAudio = () => {
        audio.play().catch(error => {
          console.error('Audio playback failed:', error);
          setIsMuted(true);
        });
      };

      audio.addEventListener('canplaythrough', () => {
        setIsAudioLoaded(true);
        if (!isMuted) {
          playAudio();
        }
      });

      return () => {
        audio.pause();
        audio.src = '';
        audio.removeEventListener('canplaythrough', playAudio);
      };
    }
  }, [currentSongIndex, volume, isMuted]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
      if (isAudioLoaded) {
        if (isMuted) {
          audioRef.current.pause();
        } else {
          audioRef.current.play().catch(console.error);
        }
      }
    }
  }, [volume, isMuted, isAudioLoaded]);

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value)
    setVolume(newVolume)
  }

  const handleVolumeSliderClose = () => {
    setShowVolumeSlider(false)
  }

  const handleEnter = () => {
    setShowLanding(false);
    setIsMuted(false);
    setTimeout(() => setShowContent(true), 1000);
  }

  const handleSongChange = (index: number) => {
    setCurrentSongIndex(index)
    setIsAudioLoaded(false)
  }

  const toggleMute = () => {
    setIsMuted(!isMuted);
  }

  const snowflakes = useMemo(() => Array.from({ length: 50 }).map((_, i) => ({
    id: i,
    size: `${Math.random() * 1.5 + 0.5}rem`,
    left: `${Math.random() * 100}%`,
    delay: `-${Math.random() * 20}s`,
    duration: `${Math.random() * 10 + 15}s`,
    opacity: Math.random() * 0.5 + 0.5,
    driftX: `${Math.random() * 150 - 75}px`,
    rotateDuration: `${Math.random() * 8 + 4}s`
  })), [])

  useEffect(() => {
    const attemptAutoplay = async () => {
      if (audioRef.current && !isMuted) {
        try {
          await audioRef.current.play();
        } catch (error) {
          console.error('Autoplay failed:', error);
          setIsMuted(true);
        }
      }
    };

    if (showContent) {
      attemptAutoplay();
    }
  }, [showContent, isMuted]);

  return (
    <>
      <AnimatePresence>
        {showLanding && <LandingPage onEnter={handleEnter} />}
      </AnimatePresence>
      
      {showContent && (
        <motion.div 
          className="min-h-screen bg-black text-white relative overflow-hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          style={{
            backgroundImage: `url(${images.background})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat'
          }}
        >
          {/* Snow Effect */}
          <div className="fixed inset-0 pointer-events-none">
            {snowflakes.map(flake => (
              <div
                key={flake.id}
                className="snowflake"
                style={{
                  '--size': flake.size,
                  '--left': flake.left,
                  '--delay': flake.delay,
                  '--duration': flake.duration,
                  '--opacity': flake.opacity,
                  '--drift-x': flake.driftX,
                  '--rotate-duration': flake.rotateDuration
                } as React.CSSProperties}
              />
            ))}
          </div>

          {/* Audio Control */}
          <div className="absolute top-4 left-4 z-20 flex items-center space-x-1 bg-zinc-800/50 rounded-2xl p-1.5">
            <motion.button
              onClick={toggleMute}
              className="w-6 h-6 flex items-center justify-center"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              aria-label={isMuted ? "Unmute audio" : "Mute audio"}
            >
              {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
            </motion.button>
            <AnimatePresence>
              {showVolumeSlider && (
                <motion.div
                  initial={{ width: 0, opacity: 0 }}
                  animate={{ width: 'auto', opacity: 1 }}
                  exit={{ width: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.01"
                    value={volume}
                    onChange={handleVolumeChange}
                    onMouseUp={handleVolumeSliderClose}
                    onTouchEnd={handleVolumeSliderClose}
                    className="w-16"
                  />
                </motion.div>
              )}
            </AnimatePresence>
            <SongDropdown 
              songs={songs} 
              currentSongIndex={currentSongIndex} 
              onSelect={handleSongChange}
              iconSize={14}
            />
            {!isAudioLoaded && (
              <div className="w-3 h-3 rounded-full bg-white/30 animate-pulse" />
            )}
            <div className="flex items-center gap-1 ml-1 border-l border-white/10 pl-1">
              <Eye className="w-3.5 h-3.5" />
              <span className="text-[10px]">3.7k</span>
            </div>
          </div>

          {/* Main Content */}
          <div className="container mx-auto px-4 py-8 flex flex-col items-center justify-center min-h-screen relative z-10">
            {/* Profile Image */}
            <motion.div 
              className="w-32 h-32 rounded-full overflow-hidden border-2 border-white/10 mb-8"
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: "spring", stiffness: 100, damping: 20, duration: 1 }}
            >
              <Image
                src={images.profile}
                alt="Profile"
                width={128}
                height={128}
                className="w-full h-full object-cover"
                priority
              />
            </motion.div>

            {/* Title with Typewriter and Glow Effect */}
            <h1 className="text-4xl font-bold mb-6 animate-glow">
              <TypeAnimation
                sequence={['bilota.x']}
                wrapper="span"
                speed={100}
                repeat={1}
              />
            </h1>

            {/* Welcome Message */}
            <motion.p 
              className="text-center text-xl max-w-2xl mb-12"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.5 }}
            >
              Welcome to my little corner of the world, where every moment feels like a warm hug. 
              Stay, vibe, and let the good energy flow.
            </motion.p>

            {/* Discord Status Card */}
            <motion.div 
              className="bg-zinc-800/80 backdrop-blur-sm rounded-2xl p-4 flex items-center gap-4 mb-12 w-full max-w-md relative group"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4, duration: 0.5 }}
            >
              <div className="relative">
                <Image
                  src={images.discord}
                  alt="Discord Avatar"
                  width={48}
                  height={48}
                  className="rounded-full"
                />
                <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 rounded-full border-2 border-zinc-800">
                  <div className="absolute inset-0 bg-green-500 rounded-full animate-ping opacity-75"></div>
                </div>
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h2 className="font-semibold text-white">bilota.x</h2>
                  <div className="flex items-center gap-1.5">
                    <DiscordBadges.ActiveDeveloper 
                      className="w-5 h-5"
                    />
                    <DiscordBadges.VerifiedDeveloper 
                      className="w-5 h-5"
                    />
                    <DiscordBadges.HypeSquad 
                      className="w-5 h-5"
                    />
                    <DiscordBadges.Bot 
                      className="w-5 h-5"
                    />
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Social Links */}
            <motion.div 
              className="flex gap-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.5 }}
            >
              {[
                { Icon: Instagram, href: "https://www.instagram.com/bilota.x" },
                { Icon: MessageSquare, href: "https://discord.com/users/1046088032920543312" },
                { Icon: Youtube, href: "https://www.youtube.com/@lyrics4.y" },
                { Icon: Mail, href: "mailto:mayanksinghrawat.ldh@gmail.com" }
              ].map((item, index) => (
                <motion.a
                  key={index}
                  href={item.href}
                  className="bg-white/10 p-4 rounded-xl hover:bg-white/20 transition-colors social-icon"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <item.Icon className="w-6 h-6" />
                </motion.a>
              ))}
            </motion.div>
          </div>
        </motion.div>
      )}
    </>
  )
}

