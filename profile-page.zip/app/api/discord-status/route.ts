import { NextResponse } from 'next/server'

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const userId = searchParams.get('userId')

  if (!userId) {
    return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
  }

  // TODO: Implement actual Discord API call here
  // For now, we'll return a mock status
  const mockStatus = {
    status: 'online',
    badges: ['Developer', 'Hypesquad']
  }

  return NextResponse.json(mockStatus)
}

