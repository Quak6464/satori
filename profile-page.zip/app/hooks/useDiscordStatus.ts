import { useState, useEffect } from 'react'

interface DiscordStatus {
  status: 'online' | 'idle' | 'dnd' | 'offline'
  badges: string[]
}

export function useDiscordStatus(userId: string) {
  const [status, setStatus] = useState<DiscordStatus | null>(null)

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const response = await fetch(`/api/discord-status?userId=${userId}`)
        if (response.ok) {
          const data = await response.json()
          setStatus(data)
        }
      } catch (error) {
        console.error('Failed to fetch Discord status:', error)
      }
    }

    fetchStatus()
    const interval = setInterval(fetchStatus, 60000) // Update every minute

    return () => clearInterval(interval)
  }, [userId])

  return status
}

